# Msoo Wa Errands Website

This is a responsive one-page website for Msoo Wa Errands.

## Included
- Responsive design for phone, tablet and desktop
- Services and charges
- 24/7 booking messaging
- Booking form that sends the customer's details to WhatsApp
- Click-to-call, email and WhatsApp buttons
- SEO title, description, keywords and LocalBusiness structured data
- Your supplied Msoo Wa Errands photo
- Facebook name updated to "graciee msoo wa errands"

## Files
- `index.html` — the complete website
- `msoo-wa-errands.jpg` — supplied business photo

## Publish with GitHub Pages
1. Create/open a GitHub repository.
2. Upload `index.html` and `msoo-wa-errands.jpg` to the repository root.
3. Open the repository's Settings → Pages.
4. Select the main branch and root folder.
5. Save and wait for GitHub Pages to publish the site.

## Getting it on Google
A published website is not automatically guaranteed to appear immediately in Google. After you have a domain/site URL:
1. Add the site to Google Search Console.
2. Verify ownership.
3. Submit the website URL/sitemap when available.
4. Keep the business name, phone number and service areas consistent online.
5. Consider creating/claiming a Google Business Profile for Msoo Wa Errands.

## Important
The current booking form sends the booking information to WhatsApp. It does not charge customers online or create a database reservation automatically. This keeps the site simple and works well with GitHub Pages. A later version can add online payments, a booking calendar, admin dashboard and automated email/SMS notifications.
